import 'package:flutter_test/flutter_test.dart';
import 'package:kartaltepe_pos/main.dart';

void main() {
  testWidgets('Uygulama açılır', (WidgetTester tester) async {
    await tester.pumpWidget(const KartaltepePosApp());
    expect(find.byType(KartaltepePosApp), findsOneWidget);
  });
}
