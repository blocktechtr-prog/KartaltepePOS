# Kartaltepe POS Mobile — Flutter + GitHub APK

Kartaltepe Otel & Restaurant için `https://restoran.turkaix.com` adresini mobil uygulama içinde açan Flutter WebView projesidir.

## Hazır özellikler

- Tam ekran POS WebView
- JavaScript, çerez ve oturum desteği
- Telefon ve tablet uyumu
- Dikey ve yatay ekran
- Android geri tuşu yönetimi
- Bağlantı hatasında tekrar deneme
- Harici bağlantıları ilgili uygulamada açma
- GitHub Actions ile telefondan otomatik APK üretme

## Telefondan APK

Ayrıntılı kurulum için `TELEFONDAN_APK_OLUSTURMA.md` dosyasını okuyun.

Özet:

1. Proje içeriğini GitHub deposuna yükleyin.
2. **Actions > Android APK Oluştur > Run workflow** yolunu kullanın.
3. Derleme tamamlandığında **Kartaltepe-POS-APK** artifact dosyasını indirin.

## Uygulama bilgileri

- Web adresi: `https://restoran.turkaix.com`
- Uygulama adı: `Kartaltepe POS`
- Paket kimliği: `com.turkaix.kartaltepepos`
- Sürüm: `1.1.0+2`

## Adres değiştirme

`lib/main.dart` içindeki `startUrl` ve `allowedHost` değerlerini değiştirin.
