import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String appName = 'Kartaltepe POS';
const String startUrl = 'https://restoran.turkaix.com';
const String allowedHost = 'restoran.turkaix.com';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations(<DeviceOrientation>[
    DeviceOrientation.portraitUp,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const KartaltepePosApp());
}

class KartaltepePosApp extends StatelessWidget {
  const KartaltepePosApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: appName,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF203D2D),
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF111613),
      ),
      home: const PosWebViewPage(),
    );
  }
}

class PosWebViewPage extends StatefulWidget {
  const PosWebViewPage({super.key});

  @override
  State<PosWebViewPage> createState() => _PosWebViewPageState();
}

class _PosWebViewPageState extends State<PosWebViewPage> {
  late final WebViewController _controller;
  int _progress = 0;
  bool _hasMainFrameError = false;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF111613))
      ..setUserAgent('KartaltepePOS/1.1 Android WebView')
      ..setNavigationDelegate(
        NavigationDelegate(
          onProgress: (int progress) {
            if (mounted) setState(() => _progress = progress);
          },
          onPageStarted: (_) {
            if (mounted) {
              setState(() {
                _hasMainFrameError = false;
                _errorMessage = '';
              });
            }
          },
          onPageFinished: (_) {
            if (mounted) setState(() => _progress = 100);
          },
          onWebResourceError: (WebResourceError error) {
            if (error.isForMainFrame == true && mounted) {
              setState(() {
                _hasMainFrameError = true;
                _errorMessage = error.description;
              });
            }
          },
          onNavigationRequest: (NavigationRequest request) async {
            final Uri? uri = Uri.tryParse(request.url);
            if (uri == null) return NavigationDecision.prevent;

            if (uri.scheme == 'http' || uri.scheme == 'https') {
              if (uri.host == allowedHost || uri.host.endsWith('.turkaix.com')) {
                return NavigationDecision.navigate;
              }
              await launchUrl(uri, mode: LaunchMode.externalApplication);
              return NavigationDecision.prevent;
            }

            if (<String>{'tel', 'mailto', 'sms', 'whatsapp'}.contains(uri.scheme)) {
              await launchUrl(uri, mode: LaunchMode.externalApplication);
            }
            return NavigationDecision.prevent;
          },
        ),
      )
      ..loadRequest(Uri.parse(startUrl));
  }

  Future<void> _handleBack() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
    } else if (mounted) {
      final bool? close = await showDialog<bool>(
        context: context,
        builder: (BuildContext context) => AlertDialog(
          title: const Text('Uygulamadan çıkılsın mı?'),
          content: const Text('Kartaltepe POS kapatılacak.'),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Vazgeç'),
            ),
            FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Çıkış'),
            ),
          ],
        ),
      );
      if (close == true) SystemNavigator.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (_, __) => _handleBack(),
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: <Widget>[
              WebViewWidget(controller: _controller),
              if (_progress < 100)
                LinearProgressIndicator(value: _progress / 100),
              if (_hasMainFrameError)
                Positioned.fill(
                  child: ColoredBox(
                    color: const Color(0xFF111613),
                    child: Center(
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 430),
                        child: Padding(
                          padding: const EdgeInsets.all(28),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              const Icon(Icons.wifi_off_rounded, size: 70),
                              const SizedBox(height: 18),
                              const Text(
                                'POS sistemine bağlanılamadı',
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  fontSize: 22,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                _errorMessage.isEmpty
                                    ? 'İnternet bağlantısını kontrol edip tekrar deneyin.'
                                    : _errorMessage,
                                textAlign: TextAlign.center,
                              ),
                              const SizedBox(height: 22),
                              FilledButton.icon(
                                onPressed: () {
                                  setState(() => _hasMainFrameError = false);
                                  _controller.loadRequest(Uri.parse(startUrl));
                                },
                                icon: const Icon(Icons.refresh_rounded),
                                label: const Text('Tekrar Dene'),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              Positioned(
                right: 12,
                bottom: 12,
                child: FloatingActionButton.small(
                  heroTag: 'reload',
                  tooltip: 'Sayfayı yenile',
                  onPressed: _controller.reload,
                  child: const Icon(Icons.refresh_rounded),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
