$ErrorActionPreference = "Stop"
Set-Location (Split-Path $PSScriptRoot -Parent)

if (-not (Get-Command flutter -ErrorAction SilentlyContinue)) {
  Write-Host "Flutter bulunamadı. Önce Flutter SDK kurun ve PATH'e ekleyin." -ForegroundColor Red
  exit 1
}

Copy-Item lib\main.dart $env:TEMP\kartaltepe_main.dart -Force
Copy-Item pubspec.yaml $env:TEMP\kartaltepe_pubspec.yaml -Force
Copy-Item analysis_options.yaml $env:TEMP\kartaltepe_analysis.yaml -Force

flutter create --platforms=android --org com.turkaix --project-name kartaltepe_pos .

Copy-Item $env:TEMP\kartaltepe_main.dart lib\main.dart -Force
Copy-Item $env:TEMP\kartaltepe_pubspec.yaml pubspec.yaml -Force
Copy-Item $env:TEMP\kartaltepe_analysis.yaml analysis_options.yaml -Force

flutter pub get

$manifest = "android\app\src\main\AndroidManifest.xml"
$content = Get-Content $manifest -Raw
if ($content -notmatch 'android.permission.INTERNET') {
  $content = $content -replace '<manifest xmlns:android="http://schemas.android.com/apk/res/android">', '<manifest xmlns:android="http://schemas.android.com/apk/res/android">`n    <uses-permission android:name="android.permission.INTERNET" />'
  Set-Content $manifest $content -Encoding UTF8
}

Write-Host "Kurulum tamamlandı." -ForegroundColor Green
Write-Host "Çalıştırma: flutter run"
Write-Host "APK: flutter build apk --release"
