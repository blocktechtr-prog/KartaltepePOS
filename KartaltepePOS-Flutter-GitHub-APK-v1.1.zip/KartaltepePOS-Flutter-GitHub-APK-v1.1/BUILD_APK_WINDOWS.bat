@echo off
cd /d %~dp0
where flutter >nul 2>nul
if errorlevel 1 (
  echo Flutter bulunamadi. Flutter SDK kurun ve PATH'e ekleyin.
  pause
  exit /b 1
)
call flutter pub get
call flutter build apk --release
if errorlevel 1 (
  echo APK derleme basarisiz.
  pause
  exit /b 1
)
echo.
echo APK hazir: build\app\outputs\flutter-apk\app-release.apk
pause
